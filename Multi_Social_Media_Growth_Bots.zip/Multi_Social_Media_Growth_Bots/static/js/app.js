document.addEventListener("DOMContentLoaded",()=>{
document.querySelectorAll(".bot-select").forEach(b=>b.addEventListener("click",()=>{
 const s=document.getElementById("platform"); if(s){s.value=b.dataset.platform;document.getElementById("launch").scrollIntoView({behavior:"smooth"});}
}));
});
